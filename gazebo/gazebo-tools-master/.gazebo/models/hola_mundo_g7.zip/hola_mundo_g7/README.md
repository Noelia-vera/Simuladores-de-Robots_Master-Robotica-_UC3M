# hola_mundo

```bash
GAZEBO_PLUGIN_PATH=build gazebo hola_mundo.world
```
